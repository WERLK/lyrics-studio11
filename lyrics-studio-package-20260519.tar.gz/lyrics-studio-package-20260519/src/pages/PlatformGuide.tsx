import { Link } from 'react-router-dom';
import { ArrowLeft, Music2, Upload, BookOpen, Info, ExternalLink, CheckCircle, AlertCircle, HelpCircle } from 'lucide-react';
import Button from '../components/ui/Button';

const platforms = [
  // 主流平台
  {
    name: '网易云音乐',
    icon: '🎵',
    color: 'from-red-500 to-red-600',
    url: 'https://music.163.com/st/musician',
    steps: [
      '注册音乐人账号',
      '登录网易云音乐创作者中心',
      '进入作品管理页面',
      '点击上传新作品',
      '填写作品信息并上传',
      '等待审核通过'
    ],
    tips: [
      '确保音频文件格式符合要求（MP3/WAV）',
      '准备好作品封面（建议尺寸 1080x1080）',
      '歌词文件建议使用 LRC 格式',
      '需要提供版权证明文件'
    ]
  },
  {
    name: 'QQ音乐',
    icon: '🎶',
    color: 'from-green-500 to-green-600',
    url: 'https://y.qq.com/studio/artist',
    steps: [
      '注册并认证音乐人',
      '进入 QQ 音乐开放平台',
      '选择上传单曲或专辑',
      '填写作品信息',
      '上传音频和歌词文件',
      '提交审核'
    ],
    tips: [
      '支持 MP3、WAV、FLAC 格式',
      '需要提供 ISRC 码（可选）',
      '确保歌词时间轴准确',
      '审核周期通常 1-3 个工作日'
    ]
  },
  {
    name: '汽水音乐',
    icon: '🥤',
    color: 'from-cyan-500 to-cyan-600',
    url: 'https://music.soda.net.cn',
    steps: [
      '下载并安装汽水音乐 App',
      '注册账号并完成实名认证',
      '进入音乐人中心申请认证',
      '创建发行方主体',
      '上传音频文件和封面',
      '提交审核并发布作品'
    ],
    tips: [
      '支持 MP3、WAV、FLAC 格式',
      '需要抖音账号授权登录',
      '封面尺寸需 1400×1400 像素以上',
      '可同步分发至抖音音乐库'
    ]
  },
  {
    name: '番茄音乐',
    icon: '🍅',
    color: 'from-orange-500 to-orange-600',
    url: 'https://music.fanqie.com/creator',
    steps: [
      '访问番茄音乐创作者平台',
      '注册并登录账号',
      '完成创作者身份认证',
      '上传音频文件和元数据',
      '设置发行信息',
      '提交审核并发布'
    ],
    tips: [
      '字节跳动旗下音乐平台',
      '支持 AI 音乐人入驻',
      '按播放时长计费收益',
      '可同步至字节系产品矩阵'
    ]
  },
  {
    name: '酷狗音乐',
    icon: '🐶',
    color: 'from-blue-500 to-blue-600',
    url: 'https://www.kugou.com/yy/html/union/apply.html',
    steps: [
      '注册酷狗音乐人账号',
      '登录创作者中心',
      '点击发布作品',
      '上传音频文件',
      '填写详细信息',
      '提交发布申请'
    ],
    tips: [
      '支持多种音频格式',
      '需要实名认证',
      '建议准备高清封面',
      '可同步上传歌词'
    ]
  },
  {
    name: '酷我音乐',
    icon: '🎹',
    color: 'from-yellow-500 to-yellow-600',
    url: 'https://www.kuwo.cn/creator',
    steps: [
      '注册酷我音乐人',
      '进入创作者后台',
      '选择上传方式',
      '填写作品信息',
      '上传文件并提交',
      '等待审核结果'
    ],
    tips: [
      '需要上传作品Demo',
      '确保文件质量达标',
      '版权声明需准确',
      '审核时间约 2-5 天'
    ]
  },
  {
    name: 'Spotify',
    icon: '🎧',
    color: 'from-green-600 to-green-700',
    url: 'https://artists.spotify.com',
    steps: [
      '通过音乐分销商注册',
      '选择合适的分销平台',
      '上传音乐文件和元数据',
      '设置发行日期和地区',
      '完成付费流程',
      '等待发布到 Spotify'
    ],
    tips: [
      '通常需要使用第三方分销商',
      '常见的分销商有 DistroKid、CD Baby 等',
      '需要准备高质量音频文件',
      '全球发行通常需要 1-2 周'
    ]
  },
  {
    name: 'Apple Music',
    icon: '🍎',
    color: 'from-gray-800 to-black',
    url: 'https://artists.apple.com',
    steps: [
      '注册 Apple Music 音乐人',
      '使用音乐分销商上传',
      '准备 WAV 或 ALAC 格式音频',
      '填写完整的元数据',
      '设置发行计划',
      '提交审核和发布'
    ],
    tips: [
      'Apple Music 对音频质量要求较高',
      '建议使用 44.1kHz/16bit WAV 格式',
      '封面尺寸建议 3000x3000 像素',
      '需要提供 ISRC 和 UPC/EAN 码'
    ]
  },
  {
    name: '咪咕音乐',
    icon: '📱',
    color: 'from-orange-600 to-orange-700',
    url: 'https://artist.migu.cn/',
    steps: [
      '注册咪咕音乐人',
      '完成实名认证',
      '进入创作者后台',
      '上传音乐作品',
      '填写作品信息',
      '提交审核发布'
    ],
    tips: [
      '支持多种音频格式上传',
      '需要提供版权证明',
      '审核周期较短',
      '可获得流量扶持'
    ]
  },
  {
    name: '喜马拉雅',
    icon: '🎙️',
    color: 'from-orange-700 to-red-700',
    url: 'https://www.ximalaya.com/creator',
    steps: [
      '注册喜马拉雅账号',
      '申请成为主播',
      '上传音频作品',
      '添加歌词描述',
      '设置作品分类',
      '发布作品'
    ],
    tips: [
      '适合有声内容创作',
      '支持多种音频格式',
      '需要完善主播资料',
      '可获得平台推荐'
    ]
  },
  {
    name: '网易音乐人',
    icon: '☁️',
    color: 'from-red-600 to-pink-600',
    url: 'https://music.163.com/st/musician',
    steps: [
      '选择入驻身份（音乐人/AI音乐人/见习音乐人）',
      '提交个人资料和原创作品',
      '完成实名认证',
      '等待平台审核',
      '通过审核后发布作品',
      '可逐步升级音乐人等级'
    ],
    tips: [
      '支持三种音乐人身份入驻',
      'AI 音乐人有专属激励计划',
      '提供天音 AI 写歌工具',
      '百万奖金 AI 音乐创作大赛进行中'
    ]
  }
];

export default function PlatformGuide() {
  return (
    <div className="min-h-screen bg-gray-950 pt-24 pb-16">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="mb-12">
          <Link
            to="/create"
            className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 mb-6 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            返回创作
          </Link>
          
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            音乐平台上传指南
          </h1>
          <p className="text-xl text-purple-200/70 max-w-2xl">
            将你的歌词和音乐作品发布到各大音乐平台，让更多人听到你的创作
          </p>
        </div>

        {/* Quick Tips */}
        <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-2xl p-6 mb-12 border border-purple-500/20">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center flex-shrink-0">
              <Info className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">上传前的准备工作</h3>
              <div className="grid md:grid-cols-3 gap-4 text-sm text-purple-200/70">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                  高质量音频文件（WAV/MP3）
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                  高清作品封面（正方形）
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                  LRC 格式歌词文件
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Platform Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {platforms.map((platform) => (
            <div
              key={platform.name}
              className="group bg-white/5 border border-white/10 rounded-2xl p-6 hover:border-white/20 hover:bg-white/10 transition-all"
            >
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${platform.color} flex items-center justify-center text-2xl shadow-lg`}>
                    {platform.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-white transition-colors">
                      {platform.name}
                    </h3>
                    <a
                      href={platform.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors"
                    >
                      访问官网
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
                <Upload className="w-6 h-6 text-purple-400 group-hover:text-purple-300 transition-colors" />
              </div>

              <div className="space-y-4">
                {/* Steps */}
                <div>
                  <h4 className="text-sm font-semibold text-purple-200/80 mb-2 flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    上传步骤
                  </h4>
                  <ol className="space-y-1">
                    {platform.steps.slice(0, 4).map((step, index) => (
                      <li key={index} className="flex items-start gap-2 text-xs">
                        <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center flex-shrink-0 text-xs font-semibold">
                          {index + 1}
                        </span>
                        <span className="text-purple-200/60">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>

                {/* Tips */}
                <div>
                  <h4 className="text-sm font-semibold text-purple-200/80 mb-2 flex items-center gap-2">
                    <HelpCircle className="w-4 h-4" />
                    温馨提示
                  </h4>
                  <ul className="space-y-1">
                    {platform.tips.slice(0, 2).map((tip, index) => (
                      <li key={index} className="flex items-start gap-2 text-xs">
                        <AlertCircle className="w-3 h-3 text-yellow-500 flex-shrink-0 mt-0.5" />
                        <span className="text-purple-200/60">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-white/10">
                <a
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full"
                >
                  <Button variant="primary" className="w-full" size="sm">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    开始上传
                  </Button>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Resources */}
        <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-2xl p-8 border border-blue-500/20">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-white mb-3">更多资源与帮助</h2>
            <p className="text-purple-200/70">需要更多帮助？查看这些有用的资源</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center p-6">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center mx-auto mb-4">
                <Music2 className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="text-white font-semibold mb-2">数字音乐发行</h3>
              <p className="text-sm text-purple-200/60">
                使用专业的数字发行平台，一次上传，全网发行
              </p>
            </div>

            <div className="text-center p-6">
              <div className="w-12 h-12 rounded-xl bg-pink-500/20 flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-6 h-6 text-pink-400" />
              </div>
              <h3 className="text-white font-semibold mb-2">版权保护</h3>
              <p className="text-sm text-purple-200/60">
                了解如何保护你的音乐作品版权
              </p>
            </div>

            <div className="text-center p-6">
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center mx-auto mb-4">
                <HelpCircle className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="text-white font-semibold mb-2">音乐人社区</h3>
              <p className="text-sm text-purple-200/60">
                加入音乐人社区，交流创作经验
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
